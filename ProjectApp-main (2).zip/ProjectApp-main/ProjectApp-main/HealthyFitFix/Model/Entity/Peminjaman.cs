﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HealthyFitFix.Model.Entity
{
	public class Peminjaman
	{
		String nama_alat,berat,jumlah,no_telp,nama,alamat,pengambilan,pengembalian;

		public Peminjaman() { }

		public Peminjaman(string nama_alat, string berat, string jumlah, string no_telp, string nama, string alamat, string pengambilan, string pengembalian)
		{
			this.Nama_alat = nama_alat;
			this.Berat = berat;
			this.Jumlah = jumlah;
			this.No_telp = no_telp;
			this.Nama = nama;
			this.Alamat = alamat;
			this.Pengambilan = pengambilan;
			this.Pengembalian = pengembalian;
		}

		public string Nama_alat { get => nama_alat; set => nama_alat = value; }
		public string Berat { get => berat; set => berat = value; }
		public string Jumlah { get => jumlah; set => jumlah = value; }
		public string No_telp { get => no_telp; set => no_telp = value; }
		public string Nama { get => nama; set => nama = value; }
		public string Alamat { get => alamat; set => alamat = value; }
		public string Pengambilan { get => pengambilan; set => pengambilan = value; }
		public string Pengembalian { get => pengembalian; set => pengembalian = value; }
	}
}
