﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HealthyFitFix.Model.Entity
{
	public class Pendaftaran
	{
		String nama, alamat, coach,berat_badan,usia,gender,no_telp;

		public Pendaftaran() { }

		public Pendaftaran(string nama, string alamat, string coach, string berat_badan, string usia, string gender, string no_telp)
		{
			this.Nama = nama;
			this.Alamat = alamat;
			this.Coach = coach;
			this.Berat_badan = berat_badan;
			this.Usia = usia;
			this.Gender = gender;
			this.No_telp = no_telp;
		}

		public string Nama { get => nama; set => nama = value; }
		public string Alamat { get => alamat; set => alamat = value; }
		public string Coach { get => coach; set => coach = value; }
		public string Berat_badan { get => berat_badan; set => berat_badan = value; }
		public string Usia { get => usia; set => usia = value; }
		public string Gender { get => gender; set => gender = value; }
		public string No_telp { get => no_telp; set => no_telp = value; }
	}
}
