﻿using HealthyFitFix.Controller;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace HealthyFitFix.View
{
    public partial class DaftarGym : Form
    {
        Koneksi koneksi=new Koneksi();  

        public void Tampil()
        {
            DataTable.DataSource = koneksi.ShowData("Select*Form healthyfit");

			DataTable.Columns[0].HeaderText = "#";
			DataTable.Columns[1].HeaderText = "ID GYM";
			DataTable.Columns[2].HeaderText = "NAMA GYM";
			DataTable.Columns[3].HeaderText = "COACH";
			DataTable.Columns[4].HeaderText = "ALAMAT";
			
		}
        public DaftarGym()
        {
            InitializeComponent();
        }

		private void DaftarGym_Load(object sender, EventArgs e)
		{
            Tampil();
		}
	}
}
