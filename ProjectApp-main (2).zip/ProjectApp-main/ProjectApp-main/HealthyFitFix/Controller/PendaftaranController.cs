﻿using HealthyFitFix.Model.Entity;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace HealthyFitFix.Controller
{
	internal class PendaftaranController
	{
		Koneksi koneksi = new Koneksi();

		public bool insert(Pendaftaran PeminjamanController)
		{
			Boolean status = false;
			try
			{
				koneksi.OpenConnection();
				koneksi.ExecuteQuery("INSERT INTO pendaftaran (Nama,Alamat,Coach,Berat_badan,Usia,Gender,No_telp) VALUES " +
					"('" + PeminjamanController.Nama + "'," +
					"'" + PeminjamanController.Alamat + "'," +
					"'" + PeminjamanController.Coach + "'," +
					"'" + PeminjamanController.Berat_badan + "'," +
					"'" + PeminjamanController.Usia + "'," +
					"'" + PeminjamanController.Gender + "'," +			
					"'" + PeminjamanController.No_telp + "')");
				status = true;
				MessageBox.Show("Data Berhasil Di tambahkan", "Informasi", MessageBoxButtons.OK, MessageBoxIcon.Information);
				koneksi.CloseConnection();

			}

			catch (Exception e)
			{
				MessageBox.Show(e.Message, "Gagal", MessageBoxButtons.OK, MessageBoxIcon.Error);
			}
			return status;
		}
	}
}
