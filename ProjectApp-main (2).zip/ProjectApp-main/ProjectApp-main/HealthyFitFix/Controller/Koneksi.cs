﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HealthyFitFix.Controller
{
	internal class Koneksi
	{
		string conectionstring = "Server=localhost;Database=healthyfit;Uid=root;Pwd=;";
		MySqlConnection kon;

		public void OpenConnection()
		{
			kon = new MySqlConnection(conectionstring);
			kon.Open();
		}

		public void CloseConnection()
		{
			kon.Close();
		}

		public void ExecuteQuery(string query)
		{
			MySqlCommand commaand = new MySqlCommand(query,kon);
			commaand.ExecuteNonQuery();

		}
		public object ShowData(string query)
		{
			MySqlDataAdapter adapter = new MySqlDataAdapter(query, conectionstring);
			DataSet data = new DataSet();

			adapter.Fill(data);
			object bebas = data.Tables[0];
			return bebas;
		}
	}
}
