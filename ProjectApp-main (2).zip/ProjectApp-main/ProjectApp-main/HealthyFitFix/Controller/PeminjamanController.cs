﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


using System.Windows.Forms;
using HealthyFitFix.Model.Repository;
using HealthyFitFix.Model.Context;
using HealthyFitFix.Model.Entity;

namespace HealthyFitFix.Controller
{ 
	public class PeminjamanController
	{
		Koneksi koneksi=new Koneksi();

		public bool insert(Peminjaman PeminjamanController)
		{
			Boolean status = false;
			try
			{
				koneksi.OpenConnection();
				koneksi.ExecuteQuery("INSERT INTO peminjaman (Nama_alat,Berat,Jumlah,No_telp,Nama,Alamat,Pengambilan,Pengembalian) VALUES " +
					"('" + PeminjamanController.Nama_alat + "'," +
					"'" + PeminjamanController.Berat + "'," +
					"'" + PeminjamanController.Jumlah + "'," +
					"'" + PeminjamanController.No_telp + "'," +
					"'" + PeminjamanController.Nama + "'," +
					"'" + PeminjamanController.Alamat + "'," +
					"'" + PeminjamanController.Pengembalian + "'," +
					"'" + PeminjamanController.Pengembalian + "')");
				status = true;	
				MessageBox.Show("Data Berhasil Di tambahkan","Informasi",MessageBoxButtons.OK, MessageBoxIcon.Information);
				koneksi.CloseConnection();

			}

			catch (Exception e)
			{ 
			MessageBox.Show(e.Message,"Gagal",MessageBoxButtons.OK,MessageBoxIcon.Error);
			}
			return status;
		}

		
	}
}
